var data;
var con;
var city;
var app = {
    
    // Application Constructor
    initialize: function() {
        this.bindEvents();
       
        console.log('initialize');
          
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        console.log('bindEvents');
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() { 
        console.log('onDeviceReady');   
        app.receivedEvent('deviceready');
        app.checkConnection();
        app.checkData();
         
    },
    receivedEvent: function(id) {
            console.log('Received Event: ' + id);
    },
    
    checkConnection: function() {
        var networkState = navigator.connection.type;

        var states = {};
        states[Connection.UNKNOWN]  = 'Unknown connection';
        states[Connection.ETHERNET] = 'Ethernet connection';
        states[Connection.WIFI]     = 'WiFi connection';
        states[Connection.CELL_2G]  = 'Cell 2G connection';
        states[Connection.CELL_3G]  = 'Cell 3G connection';
        states[Connection.CELL_4G]  = 'Cell 4G connection';
        states[Connection.CELL]     = 'Cell generic connection';
        states[Connection.NONE]     = 'No network connection';

        console.log('Connection type: ' + states[networkState]);
    },
    // Update DOM on a Received Event
    checkData: function() {
        console.log('checkData');
        
        var local=localStorage.getItem('cont');
            if(local === null){
                console.log('first time running');
                app.getData();
            }else{
                app.findContact();
            }
    },
    
    //get json data
    getData: function(){
         console.log('getData');    
         var request = new XMLHttpRequest();
         request.open('GET', 'https://dl.dropboxusercontent.com/u/887989/MAD9135/contacts.json', true);
         request.onreadystatechange = function(){
            if (request.readyState ===4){
                if(request.status===200||request.status===0){
                    var contacts = JSON.parse(request.responseText);
                    
                    for (var i = 0; i < contacts.length; i++) {
                        
                        //create a contact
                        var contact = navigator.contacts.create();
                        
                        //add a name
                        var name = new ContactName();
                        name.givenName = contacts[i].firstname;
                        name.familyName = contacts[i].lastname;
                        contact.name = name;
                        
                        //add a phone number
                        var phoneNumbers = [];
                        phoneNumbers[0] = new ContactField('mobile', contacts[i].phone, true);
                        contact.phoneNumbers = phoneNumbers;
                        
                        //add a street
                        var addresses = [];
                        addresses[0]= new ContactAddress('type','home','streetAddress',contacts[i].street,contacts[i].city,' ',' ',contacts[i].state);
                        contact.addresses = addresses;
                        
                        //add an email
                        var emails = [];
                        emails[0] = new ContactField('personal',contacts[i].email, true);
                        contact.emails = emails;
                        
                        contact.save(app.showDefault,app.saveError);
                                            
                     }
                    
                 }
            }
           
       };
        request.send();
	 
    },
    
    // find contact
    findContact: function(){
        
        console.log('findContact');
        
        var options = new ContactFindOptions();
        var fields = ["displayName", "name"];
        navigator.contacts.find(fields, app.findContactSuccess, app.findContactError, options);
    },
    
    //find contact success call 
    findContactSuccess: function (contacts) {
        
		console.log('findContactSuccess');
		
        var contactList=$('.contactList li');
        if(contactList){
            $('.contactList li').remove();
        }
        
        for (var i = 0; i < contacts.length; i++) {        
            $('.contactList').append("<li data-i='"+i+"'><a href='#'>"+contacts[i].name.givenName+" "+contacts[i].name.familyName+"</a></li>");
            $("li").addClass("link");
        }

        var add = $('#first .add');
        if(add){
            $('#first .add').remove();
        }
            $('#first').append("<a href='#' class='add'>Add Contact</a>");

        con= contacts;
        console.log(con);

        $('li').bind('click',app.showContacts);
        $('.add').bind("click",app.showLocation);
        
          
    },
    
    //show contacts
    showContacts: function(){
       
        data = $(this).attr("data-i");
		
        $('#first').attr('class', 'hide');
        $('#second').attr('class', 'show');

        var form=$('.form');
        if(form){
            $('.form').remove();
        }
        
        $('#second').append('<form class="form"></form');
          
        var html = '<h1>' + con[data].name.givenName + ' ' + con[data].name.familyName + '</h1>';
            html += '<div class="contactForm">'; 


            html +='<li><label for= "firstname" >Firstname : </label><input type="text" name="firstname" value="'+con[data].name.givenName+'"></li>';

            html +='<li><label for= "firstname" >Lastname : </label><input type="text" name="lastname" value="'+con[data].name.familyName+'"></li>';

            for(var j = 0; j < con[data].addresses.length; j++) {
              html += '<li><label for= "street" >Street : </label><input type="text" name="street" value="'+con[data].addresses[j].streetAddress+'"></li>';

              html += '<li><label for= "city" >City : </label><input type="text" name="city" value="'+con[data].addresses[j].locality+'"></li>';

              html += '<li><label for= "state" >State : </label><input type="text" name="state" value="'+con[data].addresses[j].country+'"></li>';
            }

            if(con[data].phoneNumbers.length!=0){
                for(var k = 0; k < con[data].phoneNumbers.length; k++){
                    html += '<li><label for= "mobile" >Mobile: </label><input type="text" name="mobile" value="'+con[data].phoneNumbers[k].value+'"></li>';
                }
            }else{
                 html += '<li><label for= "mobile" >Mobile: </label><input type="text" name="mobile" value=""></li>';
            }

            for(var h=0;h<con[data].emails.length;h++){
                html += '<li><label for= "email" >Email: </label><input type="text" name="email" value="'+con[data].emails[h].value+'"></li>';
            }

            html+= '<a class="edit">Save</a><a class="back">Back</a>';
        
            html += '</div>';
        

            $('.form').append(html);

            $('.edit').bind('click',app.change);
            $('.back').bind('click', app.goBack);

    },
    
    //make change
    change:function(ev){
        ev.preventDefault();

        con[data].name.givenName=$('input:eq(0)').val();
        con[data].name.familyName=$('input:eq(1)').val();
        con[data].addresses[0].streetAddress=$('input:eq(2)').val();
        con[data].addresses[0].locality=$('input:eq(3)').val();
        con[data].addresses[0].country=$('input:eq(4)').val();

        con[data].phoneNumbers[0].value=$('input:eq(5)').val();
        con[data].emails[0].value=$('input:eq(6)').val();

        con[data].save(app.onSaveSuccess,app.saveError);        
    },
    
    //back call
    goBack:function(){
       	     
        $('#second').attr('class', 'hide');
        $('#first').attr('class', 'show');
			        
    },
    
    //show default 5 contacts
    showDefault:function(){
        
        console.log('show default');
        
        localStorage.setItem('cont','1');
        
        app.findContact();
       
    },
    

    //show location
    showLocation:function(){
        navigator.geolocation.getCurrentPosition(app.onSuccess, app.onError);
     },
    
    //show location success call
    onSuccess :function(position){
        
            console.log("lat: "+position.coords.latitude);
            console.log("lon: "+position.coords.longitude);
            lat=position.coords.latitude;
            lon=position.coords.longitude;
        
            var request = new XMLHttpRequest();
                request.open('GET', 'http://open.mapquestapi.com/geocoding/v1/reverse?' + 'key=Fmjtd|luur2hurn0%2Cbg%3Do5-9wasly&location=' + lat + ',' + lon, true);
                request.onreadystatechange = function(){
                     if (request.readyState ===4){
                         if(request.status===200||request.status===0){
                             city =JSON.parse(request.responseText);
                             app.addContact();
                             console.log(city);                 
                 }
             }
        };
        request.send();
        
},

//error call back
onError: function(error){
    
            console.log('code: '    + error.code    + '\n' +
                  'message: ' + error.message + '\n');
            app.addContact();
},
    
//add contact
addContact:function (){     
	  
    $('#first').attr('class', 'hide');
    $('#second').attr('class', 'show');
	 
       
    var form=$('.form');
        if(form){
            $('.form').remove();
        }
    
        $('#second').append('<form class="form"></form');
    
        var html = '<h1>New Contact</h1>'
            html += '<div class="contactForm">'; 


            html +='<li><label for= "firstname" >Firstname : </label><input type="text" name="firstname" value=""></li>';

            html +='<li><label for= "firstname" >Lastname : </label><input type="text" name="lastname" value=""></li>';

            if(city === undefined){
                
              html += '<li><label for= "street" >Street : </label><input type="text" name="street" value=""></li>';

              html += '<li><label for= "city" >City : </label><input type="text" name="city" value=""></li>';

              html += '<li><label for= "state" >State : </label><input type="text" name="state" value=""></li>';
            }else{
                
              html += '<li><label for= "street" >Street : </label><input type="text" name="street" value="'+city.results[0].locations[0].street+'"></li>';

              html += '<li><label for= "city" >City : </label><input type="text" name="city" value="'+city.results[0].locations[0].street+'"></li>';

              html += '<li><label for= "state" >State : </label><input type="text" name="state" value="'+city.results[0].locations[0].street+'"></li>';
            
            }


            html += '<li><label for= "mobile" >Mobile: </label><input type="text" name="mobile" value=""></li>';
                
            html += '<li><label for= "email" >Email: </label><input type="text" name="email" value=""></li>';
    
            html+= '<a class="save">Save</a><a class="back">Back</a>';

            html += '</div>';
			
            $('.form').append(html);
        
            $('.back').bind('click', app.goBack);
            $('.save').bind('click', app.saveContact);

    },
    
    
    // save contact
    saveContact:function(){

         var contact = navigator.contacts.create();

         var name = new ContactName();

             if ($('input:eq(0)').val() == '') {
                name.givenName = ' ';

             }else{

                name.givenName = $('input:eq(0)').val();
             }
             if ($('input:eq(1)').val() == '') {

                name.familyName =$('input:eq(1)').val(' ');
             }else{

                 name.familyName =$('input:eq(1)').val();
             }

             var addresses=[];

             if($('input:eq(2)').val()==''){
                var street = ' ';
             }else{
                 var street = $('input:eq(2)').val();
             }

             if($('input:eq(3)').val()==''){
                var currentCity = ' ';
             }else{
                var currentCity = $('input:eq(3)').val();
             }

             if($('input:eq(4)').val()==''){
               var state = ' ';
             }else{
                var state = $('input:eq(4)').val();
             }

             addresses[0]=new ContactAddress('type','home','streetAddress',street,currentCity,' ',' ',state);

             console.log(addresses);

             var phoneNumbers =[];
             if($('input:eq(5)').val()==''){
               phoneNumbers[0] =new ContactField('mobile',' ');
             }else{
                phoneNumbers[0] =new ContactField('mobile',$('input:eq(5)').val());
             }

             console.log(phoneNumbers);

             var emails=[];
             if($('input:eq(6)').val()==''){
                emails[0] =new ContactField('home',' ');

             }else{
                emails[0] =new ContactField('home',$('input:eq(6)').val());
             }

             // save
             contact.displayNmae = name;
             contact.name = name;
             contact.phoneNumbers = phoneNumbers;
             contact.addresses = addresses;
             contact.emails = emails;

             contact.save(app.onSaveSuccess,app.onSaveContactError);

    },
    
    //success call back
    onSaveContactSuccess:function(){
        app.goBack();
    },
   
//error call back
    offline:function(){
        alert('offLine');
    },
    
    findContactError: function (contactError) {
        alert('onError!');
    },
    
    onSaveSuccess: function (contact) {
        var notification =$('#second .notification');
        if(notification){
           $('#second .notification').remove();
        }
         $('#second').append('<div class="notification">Contact Saved</div>');
        setTimeout(function(){$('#second .notification').remove();},2000);
        
    },

    saveError:function (contactError) {
        console.log("Error = " + contactError.code);
    }
};


(function init() {
     app.initialize();
})();
var links = [];
var pages = [];
var numLinks = 0;
var numPages = 0;

window.addEventListener('DOMContentLoaded', function() {
   app.initialize(); 
});

var app = {
    initialize: function() {
        alert("App Initialized!");
        this.bindEvents();
        //app.appStart();
    },
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    onDeviceReady: function() {
        app.getContacts();
        app.appStart();
    },
    getContacts: function() {
        var request = new XMLHttpRequest();
		request.open("GET", "https://dl.dropboxusercontent.com/u/887989/MAD9135/contacts.json", true);
		request.onreadystatechange = function() {
			if (request.readyState == 4) {
				if (request.status == 200 || request.status == 0) {
					var result = JSON.parse(request.responseText);
                    console.log(result);
				}
			}
		};
		request.send();
    },
    appStart: function() {
        links = document.querySelectorAll("[data-role='link']");
        pages = document.querySelectorAll("[data-role='page']");
        numLinks = links.length;
        numPages = pages.length
        
        for (var l=0; l<numLinks; l++) {
            links[l].addEventListener('click', this.handleClick, false);
        }
    },
    handleClick: function(link) {
        link.preventDefault();
        var href = link.currentTarget.href;
        var parts = href.split("#");
        app.loadPage(parts[1]);
    },
    loadPage: function(page) {
        for (var p=0; p<numPages; p++) {
            if (pages[p].id == page) {
                pages[p].className = "active";
            } else {
                pages[p].className = "";
            }
        }
    }
 };
